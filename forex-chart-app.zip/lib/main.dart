import 'package:flutter/material.dart';

void main() => runApp(const ChartApp());

class ChartApp extends StatelessWidget {
  const ChartApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'محلل الشارت',
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF101820),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF19B58A),
          brightness: Brightness.dark,
        ),
        useMaterial3: true,
      ),
      home: const Dashboard(),
    );
  }
}

class Dashboard extends StatelessWidget {
  const Dashboard({super.key});

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('محلل الشارت الذكي'),
          centerTitle: true,
        ),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            const Text('لوحة التحليل', style: TextStyle(fontSize: 23, fontWeight: FontWeight.bold)),
            const SizedBox(height: 14),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: const [
                    Text('زوج التداول', style: TextStyle(color: Colors.white70)),
                    SizedBox(height: 8),
                    Text('EUR/USD  •  إطار 15 دقيقة', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
                    SizedBox(height: 18),
                    Text('الرسم البياني', style: TextStyle(fontWeight: FontWeight.bold)),
                    SizedBox(height: 12),
                    SizedBox(
                      height: 130,
                      child: Center(
                        child: Text('سيظهر الرسم البياني بعد ربط مزود بيانات السوق',
                          textAlign: TextAlign.center,
                          style: TextStyle(color: Colors.white60)),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 12),
            const IndicatorTile(name: 'RSI', value: '—', note: 'بانتظار بيانات السوق'),
            const IndicatorTile(name: 'MACD', value: '—', note: 'بانتظار بيانات السوق'),
            const IndicatorTile(name: 'EMA 20 / 50', value: '—', note: 'بانتظار بيانات السوق'),
            const SizedBox(height: 12),
            Card(
              color: const Color(0xFF202D38),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: const [
                    Text('إشارة التحليل', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                    SizedBox(height: 10),
                    Text('انتظار البيانات', style: TextStyle(fontSize: 22, color: Colors.amber, fontWeight: FontWeight.bold)),
                    SizedBox(height: 8),
                    Text('هذه نسخة تأسيسية للواجهة فقط. لا تصدر توصية شراء أو بيع قبل ربط بيانات حقيقية وحساب المؤشرات.',
                      style: TextStyle(color: Colors.white70, height: 1.5)),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class IndicatorTile extends StatelessWidget {
  final String name;
  final String value;
  final String note;
  const IndicatorTile({super.key, required this.name, required this.value, required this.note});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
        title: Text(name, style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text(note),
        trailing: Text(value, style: const TextStyle(fontSize: 18)),
      ),
    );
  }
}
